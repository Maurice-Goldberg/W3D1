player_1, player_2 = Player.new, Player.new
new_game = Game.new(player_1, player_2)